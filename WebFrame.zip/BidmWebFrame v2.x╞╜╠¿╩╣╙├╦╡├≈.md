# BidmWebFrame v2.x平台使用说明

## 1. 概览

### 1.1 平台简介

BidmWebFrame开发平台采用当下流行的SpringBoot、Angular、HTML5等技术，旨在帮助开发人员快速简便搭建WEB系统开发环境，使其更加专注于业务功能开发，提升系统开发效率。

### 1.2 功能亮点

① 系统功能：用户管理、权限管理、日志记录等；
② 通用功能：BOE用户中心认证、邮件发送、消息通知（BOE微信、移动门户等）
③ 全局统一接口：无需纠结接口路径定义，可自定义接口名字；
④ 多数据库支持：利用注解选择数据库连接；
⑤ 功能菜单自定义
⑥ 动态SQL：逻辑修改后无需重新部署；
⑦ 版本升级：简便快捷，更快更好的使用平台最新功能

## 2. 使用说明

### 2.1 项目获取及启动

项目获取地址：（地址尚在建设中，请联系平台负责人 [张岩](MeiCloud://Message/?uid=10076561) [吕明涛](MeiCloud://Message/?uid=111079)）

1. 将获取的项目以Maven Project的方式导入STS(Spring Tool Suite)，并修改pom.xml中的项目名称、版本信息，以及bidm.properties中的数据库信息（具体参考一下章节），运行时以SpringBoot Application的方式。
2. 使用Visual Studio Code打开src/main/webapp目录，修改package.json和angular.json中的项目名称和版本信息，并在终端窗口首先输入npm install命令，安装完成后，再输入npm start命令即可运行。

### 2.2 系统页面

平台中已包含的页面有：用户管理、角色管理、菜单管理、参数设置、SQL管理、登录日志、菜单点击日志等，各项目可根据实际需要选择展示。

### 2.3 功能菜单自定义

页面右上角的功能菜单可根据系统需要进行自定义，原平台提供的下拉菜单中也可以增加菜单项。

![avatar][top-menu] ![avatar][sys-menu]

app.component.ts中的topMenus和sysMenus分别对应上述两类菜单，可进行修改。


## 3. API说明（带*为BOE内部使用）

### 3.1 BIDM API

### 3.2 邮件系统

#### 3.2.1 类描述

类名 | 说明
:-: | :-
MailUtils | 邮件发送主类

#### 3.2.2 详细介绍

##### 3.2.2.1 MailUtils

**Constructor**

Constructor | Description
:- | :-
public MailUtils(String user, String password) | 
public MailUtils(String user, String password, String smtp, int port) |

**Fields**

Name | Access | Type | Default | Description
:-: | :-: | :-: | :-: | :-
smtp | private | String | mail.boe.com.cn |
smtpPort | private | int | 465 |
user | private | String | |
password | private | String | |
from | private | String | | 默认与user相同
toes | private | List&lt;String&gt; | | 收件人列表
cces | private | List&lt;String&gt; | | 抄送人列表
bccs | private | List&lt;String&gt; | | 密送人列表
subject | private | String | | 邮件标题
content | private | String | | 邮件内容
attachments | private | List&lt;String&gt; | | 附件路径列表
tmpl | private | Tmpl | | 邮件模板（使用setTmpl方法设置）
images | private | List&lt;String&gt; | | 模板中图片列表

**Methods**

Name | Function | Description
:- | :- | :-
addTo | public void addTo(String address) | 增加收件人邮箱（不可添加错误的格式）
addCc | public void addCc(String address) | 增加抄送人邮箱（不可添加错误的格式）
addBcc | public void addBcc(String address) | 增加密送人邮箱（不可添加错误的格式）
addAttachment | public void addAttachment(String attachPath) | 增加附件
setTmpl | public void setTmpl(String path, Object[] args) | 设置模板，并将模板中{0}、{1}...类参数赋值
setTmpl | public void setTmpl(String path, Object[] args, HashMap<String, String> params) | 设置模板，将模板中参数赋值（包括 {0}、{1}...及[[param]]类）
send | public void send() throws BidmException | 参数设置后，发送邮件

**模板示例**
```
<table style="width:100%;" cellpadding="1" cellspacing="0" border="2" bordercolor="#337FE5">
<tr><td style="border:none;padding:18px;">
	<table style="width:100%;font-family:&quot;微软雅黑&quot;,&quot;sans-serif&quot;;" border="0">
	<tr><td style="border:none;padding:12px;">
		<p align="right" style="text-align:right;font-size:24pt;">[[appname]]</p>
	</td></tr>
	<tr><td style="border:none;padding:12px;">
		<p align="left" style="text-align:left;font-size:18pt;">{0}</p>
	</td></tr>
	<tr><td style="border:none;padding:12px;">
		<p align="left" style="text-align:left;"><span>[[greeting]]&nbsp;{1}:</span></p>
	</td></tr>
	<tr><td style="border:none;padding:12px;">
		<p align="left" style="text-align:left;"><span>
			如需重置密码，请点击以下链接<br/><a href="{2}">{0}</a>
		</span></p>
	</td></tr>
	<tr><td style="padding:12px;border-top:thin dashed;">
		<span align="left" style="font-size:9.0pt;font-weight:bold;color:gray;mso-no-proof:yes">
		    [[signature]]
		</span>
	</td></tr>
	<tr><td style="padding:12px;">
		<span align="left" style="font-size:9.0pt;color:gray;mso-no-proof:yes">
		    [[attention]]
		  <a href="mailto:{3}">{3}</a>
		</span>
	</td></tr>
	</table>
</td></tr>
</table>
```

### 3.3 Tibco

### 3.4 日期

### 3.5 HTTP API

### 3.6 Format API

### 3.7 字符串操作

#### 3.7.1 类描述

类名 | 说明
:-: | :-
StringKits | 字符串主类

#### 3.7.2 详细介绍

##### 3.7.2.1 StringKits

**Methods**

Name | Function | Description
:- | :- | :-
join | public static String join(List<String> list, String splitter) |
join | public static String join(String[] strs, String splitter) |
join | public static String join(HashMap<String, ?> kvs, String pairConnector, String splitter) |
join | public static String join(HashMap<String, ?> kvs) |

### 3.8 JWT

#### 3.8.1 类描述

类名 | 说明
:-: | :-
JwtUtils | JWT主类

#### 3.8.2 详细介绍

##### 3.8.2.1 JwtUtils

**Methods**

Name | Function | Description
:- | :- | :-
create | public static String create(String id, String issuer, String subject) | 创建JWT加密字串（无超时）
create | public static String create(String id, String issuer, String subject, long timeoutMillis) | 创建JWT加密字串（有超时）
parse | public static Claims parse(String jwt) throws BidmException | 解析JWT

### 3.9 加密

#### 3.9.1 类描述

类名 | 说明
:-: | :-
EncryptKits | 加密主类

#### 3.9.2 详细介绍

##### 3.9.2.1 EncryptKits

**Methods**

Name | Function | Description
:- | :- | :-
MD5 | public static String MD5(String s) | 普通MD5加密
getMd5 | public static String getMd5(String s) | BIDM用户密码加密（与用户中心统一）
mesEncrypt | public static String mesEncrypt(String text) | MES加密
mesDecrypt | public static String mesDecrypt(String text) | MES解密

### 3.10* BOE移动门户

使用BOE移动门户发送消息，需要联系集团办公IT解决方案部，申请服务号。

#### 3.10.1 类描述

类名 | 说明
:-: | :-
BoePortal | BOE移动门户信息发送主类
BoePortalParam | BOE移动门户参数定义类
BoePortalMessage | BOE移动门户消息类

#### 3.10.2 详细介绍

##### 3.10.2.1 BoePortalParam

**Fields**

Name | Access | Type | Default | Description
:-: | :-: | :-: | :-: | :-
appKey | private | String | - | 服务号的appKey
sysKey | private | String | - | 服务号的sysKey
secret | private | String | - | 服务号的secret
accessToken | private | String | - | 服务号的accessToken，第三方调用标识
prod | private | boolean | true | 是否为生产环境

##### 3.10.2.2 BoePortalMessage

**Fields**

Name | Access | Type | Default | Description
:-: | :-: | :-: | :-: | :-
sourceType | private | String | todo | 推送来源（无需修改）
realPush | private | String | y | y/n 设置为n时，消息会存在消息中心，但不会被推送（无需修改）
title | private | String | - | 消息标题
noticeTitle | private | String | - | 手机通知内容，IOS通知栏会显示此内容，此值不传时，显示title的内容
listDepartment | private | List&lt;String&gt; | - | 推送的部门ID列表（暂不使用）
listUser | private | List&lt;String&gt; | - | 推送人员工号列表
shareRange | private | Integer | 0 | 0-不允许分享 1-只分享到美信 2-不限 （尚不清楚该参数含义，不必修改）
openType | private | Integer | 3 | 0-PC和移动端只收提醒不能打开，1-只支持PC端打开，2-只支持移动端打开，3-PC和移动端均可打开
jumpUrl | private | String | - | 消息点击跳转的Url
coverImgUrl | private | String | - | 消息封面图片Url
summary | private | String | - | 消息摘要

**Methods**

Name | Function | Description
:- | :- | :-
addUser | public void addUser(String user) | 增加推送用户的工号
setOpenType | public void setOpenType(MsgOpenType openType) | 设置消息打开类型（NONE/PC/MOBILE/ALL）
setRealPush | public void setRealPush(boolean realPush) | 见上述描述

##### 3.10.2.3 BoePortal

**Methods**

Name | Function | Description
:- | :- | :-
init | public static void init(BoePortalParam params) | 设置服务号参数
sendMsg | public static void sendMsg(BoePortalMessage message) | 推送消息（必须先调用init方法）
sendMsg | public static void sendMsg(BoePortalParam params, BoePortalMessage message) | 推送消息（上面两个方法的合并）

**Example**

```
BoePortalParam params = new BoePortalParam();
params.setAppKey("your appkey");
params.setSysKey("your syskey");
params.setSecret("your secret");
params.setAccessToken("your accessToken");

BoePortalMessage message = new BoePortalMessage();
message.setTitle("Title");
message.addUser("123456789");
message.setSummary("summary");
message.setJumpUrl("http://www.boe.com.cn");

BoePortal.init(params);
BoePortal.sendMsg(message);

//BoePortal.sendMsg(params, message);
```

## 4. WEB接口

### 4.1 概述

BIDM WebApplication平台接口消息采用JSON格式，所有字段类型均为String以减小设备间的差异性，接口请求方式采用HTTP(S)，可以为GET、POST等，接口地址以实际公布为准。其他使用本平台的项目在接口设计时也可参考。

### 4.2 接口请求格式

字段名称 | 描述
:-: | :-
method | 方法名称（必填）
checksum | 接口调用需要（暂时不使用）
params | 参数列表，采用key: value格式，详见各接口

**接口示例**
```
{
	"method": "get-user",
	"checksum": "1",
	"params": {
		"account": "10076561"
	}
}
```

### 4.3 接口响应格式

字段名称 | 描述
:-: | :-
method | 方法名称（必填）
code | 消息响应代码
message | 错误信息（执行成功时可没有该字段）
checksum | 接口调用需要（暂时不使用）
params | 参数列表，采用key: value格式，详见各接口

**接口示例**
```
{
	"method": "get-user",
	"code": "0",
	"message": "success",
	"checksum": "1",
	"params": {
		"account": "10076561"
	}
}
```
### 4.4 BIDM定义及调用方式

#### 4.4.1 接口定义（Server）

接口定义类（Action）使用注解 @BidmApplication，接口方法使用注解 @BidmMethod。

注解 @BidmMethod中，参数name即为该接口名称。

**接口定义方法格式：**
public BidmResponse *method*(BidmRequest request)

**接口中获取参数：**
BidmUtils.getRequestParam(request, 'param-name'[, 'default-value'])

```
@BidmApplication
public class BidmDemoAction {

	@BidmMethod(name = "method-1")
	public BidmResponse method1(BidmRequest request) throws BidmException {
		
		String param1 = BidmUtils.getRequestParam(request, "param1", "bidm");
		String param2 = BidmUtils.getRequestParam(request, "param2");

		... ...

		BidmResponse response = new BidmResponse();
		response.setErrorCode(ErrorCode.BIDM_SUCCESS);
		return response;
	}

}
```

#### 4.4.2 接口调用（Client）

BIDM平台提供BidmService来调用上面所定义的接口。

```
constructor(bidm: BidmService) {}

function() {
	this.bidm.request('method-1', { k1: v1, k2: v2 }).then(
		res => {
			const result: BidmResult = this.bidm.check(res, 'method-1');
			if (result.isSuccess) {
				...
			} else {
				...
			}
		}		
	);
}
```

### 4.5 接口详情

### 4.6 错误代码

代码 | 描述 | 代码 |描述 | 代码 | 描述 
:-: | :- | :-: | :- | :-: | :- 
**0** | 执行成功 | **200** | 执行成功 | **99999** | 执行失败
**10001** | 用户不存在 | **10002** | 用户密码不允许修改 | **10003** | 用户未注册
**10004** | 用户密码错误 | **10005** | 用户已在其他地点登录 | **10006** | 用户Token错误
**10007** | 输入新密码不一致 | **10008** | 用户Token超时 
**10090** | 系统尚未设置负责人 | **10091** | 负责人无效
**90001** | 未知方法名 | **90002** | 缺少参数 | **90003** | 参数格式有误
**90004** | 参数值错误 | **90005** | 请求格式有误 | **90006** | 用户权限不足
**90007** | 请求参数有误 | **90008** | 项目不存在

## 5. 数据库表

### 5.1 BIDM_USERINFO

**用户信息表** 用于存储系统中的用户信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**USERACCOUNT** | 用户账号 | VARCHAR2 | 32 | √ | √ |
**USERNAME** | 用户姓名 | VARCHAR2 | 64 | | |
**CREATEUSER** | 创建人账号 | VARCHAR2 | 32 | | √ |
**CREATETIME** | 创建时间 | TIMESTAMP | | | √ |
**UPDATEUSER** | 更新人账号 | VARCHAR2 | 32 | | |
**UPDATETIME** | 更新时间 | TIMESTAMP | | | |
**STATE** | 状态（0-禁用 1-启用）| NUMBER | | | √ | 1
**PASSWORD** | 密码（密文） | VARCHAR2 | 255 | | |
**TYPE** | 用户类型（0-普通 1-登录不超时） | NUMBER | | | √ | 0
**ISUNIFIED** | 是否统一认证（0-系统认证 1-统一认证） | NUMBER | | | √ | 0
**TOKEN** | 用户Token | VARCHAR2 | 255 | | |
**TOKENTIME** | 用户Token时间 | TIMESTAMP | | | |

### 5.2 BIDM_USERDETAIL

**用户详细信息表** 用于存储系统中的用户详细信息，统一认证的用户不在此表存储

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**USERCODE** | 用户账号 | VARCHAR2 | 32 | √ | √ |
**USERNAME** | 用户姓名 | VARCHAR2 | 64 | | |
**GENDER** | 性别（1-男 2-女） | NUMBER | | | |
**WORKPLACE** | 工作地 | VARCHAR2 | 16 | | |
**NATIONALITY** | 国籍 | VARCHAR2 | 32 | | |
**ORGPATH** | 所在组织 | VARCHAR2 | 255 | | |
**TELEPHONE** | 电话号码 | VARCHAR2 | 255 | | |
**MOBILE** | 手机号码 | VARCHAR2 | 255 | | |
**EMAIL** | 邮箱地址 | VARCHAR2 | 255 | | |

### 5.3 BIDM_ROLEINFO

**角色信息表** 用于存储系统中的角色信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**ROLEID** | 角色ID | VARCHAR2 | 32 | √ | √ |
**DESCRIPTION** | 描述 | VARCHAR2 | 255 | | |
**CREATEUSER** | 创建人账号 | VARCHAR2 | 32 | | √ |
**CREATETIME** | 创建时间 | TIMESTAMP | | | √ |
**UPDATEUSER** | 更新人账号 | VARCHAR2 | 32 | | |
**UPDATETIME** | 更新时间 | TIMESTAMP | | | |
**STATE** | 状态（0-禁用 1-启用）| NUMBER | | | √ | 1

### 5.4 BIDM_MENUINFO

**菜单信息表** 用于存储系统中的菜单信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**MENUID** | 菜单ID | VARCHAR2 | 32 | √ | √ |
**ICON** | 菜单图标 | VARCHAR2 | 64 | | |
**ROUTERLINK** | 菜单URL | VARCHAR2 | 255 | | |
**PARENTID** | 父菜单ID | VARCHAR2 | 32 | | |
**DESCRIPTION** | 描述 | VARCHAR2 | 255 | | |
**SORT** | 菜单排序 | VARCHAR2 | 8 | | |
**ISLEAF** | 是否叶节点 | NUMBER | | | |
**CREATEUSER** | 创建人账号 | VARCHAR2 | 32 | | √ |
**CREATETIME** | 创建时间 | TIMESTAMP | | | √ |
**UPDATEUSER** | 更新人账号 | VARCHAR2 | 32 | | |
**UPDATETIME** | 更新时间 | TIMESTAMP | | | |
**STATE** | 状态（0-禁用 1-启用）| NUMBER | | | √ | 1
**TAGS** | 菜单标签 | VARCHAR2 | 255 | | |

### 5.5 BIDM_USERROLELINK

**用户角色关联表** 用于存储系统中的用户与角色的关联信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**USERACCOUNT** | 用户账号 | VARCHAR2 | 32 | √ | √ |
**ROLEID** | 角色ID | VARCHAR2 | 32 | √ | √ |

### 5.6 BIDM_ROLEMENULINK

**角色菜单信息表** 用于存储系统中的角色与菜单的关联信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**ROLEID** | 角色ID | VARCHAR2 | 32 | √ | √ |
**MENUID** | 菜单ID | VARCHAR2 | 32 | √ | √ |

### 5.7 BIDM_USER_LOGIN_INFO

**用户登录信息表** 用于存储系统中的用户登录的相关信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**USERACCOUNT** | 用户账号 | VARCHAR2 | 32 | | √ |
**USERNAME** | 用户姓名 | VARCHAR2 | 64 | | |
**LOGINTIME** | 登录时间 | TIMESTAMP | | | √ |
**LOGOUTTIME** | 登出时间 | TIMESTAMP | | | |
**IPADDR** | IP地址 | VARCHAR2 | 16 | | |
**CLIENT** | 客户端信息 | VARCHAR2 | 128 | | |
**VERIFYKEY** | 标识码 | VARCHAR2 | 8 | | √ |

### 5.8 BIDM_PARAM

**参数信息表** 用于存储系统中的参数信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**KEY** | 参数标识 | VARCHAR2 | 32 | √ | √ |
**VALUE** | 参数值 | VARCHAR2 | 255 | | |
**FLAG** | 标记（0-不可删除 1-可删除） | NUMBER | | | √ | 1
**DESCRIPTION** | 描述 | VARCHAR2 | 255 | | |

### 5.9 BIDM_SQL

**SQL表** 用于存储系统中的自定义SQL

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**ID** | SQL ID | VARCHAR2 | 32 | √ | √ |
**SQL** | SQL | VARCHAR2 | 4000 | | √ |
**IDX** | 数据库标记 | NUMBER | | | √ | 0
**CANDELETE** | 删除标记（0-不可删除 1-可删除） | NUMBER | | | √ | 1

### 5.10 BIDM_LANGUAGE

**语言信息表** 用于存储系统中的所支持的语言信息

Column | 描述 | 类型 | 长度 | 主键 | NOT NULL | 默认值
:-: | :- | :-: | :-: | :-: | :-: | :-:
**ID** | 语言ID | VARCHAR2 | 16 | √ | √ |
**NAME** | 语言描述 | VARCHAR2 | 64 | | |

## 6. 多数据源使用

### 6.1 配置

系统数据库配置在bidm.properties中，文件位置为Maven Project的resources目录（若不存在，请自行创建）

配置方法：com.boe.bidm.db[*idx*][*key*]

*idx* - 数据库索引标记（从0开始）

*key* - 配置项key

配置项key | 说明
:-: | :-
**driver** | DB连接驱动
**url** | DB地址及参数
**username** | DB用户名
**password** | DB密码

```
com.boe.bidm.db[0][driver] = oracle.jdbc.driver.OracleDriver
com.boe.bidm.db[0][url] = jdbc:oracle:thin:@127.0.0.1:1521/bidmdb
com.boe.bidm.db[0][username] = user
com.boe.bidm.db[0][password] = pwd

com.boe.bidm.db[1][driver] = com.mysql.cj.jdbc.Driver
com.boe.bidm.db[1][url] = jdbc:mysql://@127.0.0.1:3306/bidmdb?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8
com.boe.bidm.db[1][username] = user
com.boe.bidm.db[1][password] = pwd
```

### 6.2 使用

在对应的Mapper定义时，增加注解 @TargetDataSource("bidm-db-*idx*")，其中*idx*为配置项中对应*idx*，无此注解时，默认使用idx为0的DB

```
@Mapper
@TargetDataSource("bidm-db-1")
public interface BidmMapper {
	... ...
}
```

## 7. 动态SQL

### 7.1 说明
### 7.2 使用

## 8. 参数设置

### 8.1 说明
### 8.2 BIDM参数

## 9. 日志管理

## 10. 版本升级

### 10.1 Server升级
### 10.2 Client升级


[top-menu]:data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAABtCAIAAAE163aFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAArrSURBVHhe7Z3PaxzJFcd1yCWHHHJd1rrs3oIhx1xy08mIRaBcgmFZCCE4JLuyhfGiYLEK3kSJdRjhhBVe2ExIvD8E1gzOQfYuzgonEzBjYwUh2bInklYzs0Ke9oz0H+RVV3dN9evqnqrurv4NH4au16+m+tuvqrqnuqZ6bGzpUShwWpre4JRs8CYh4EdBRuuTt/qA8i+s2kbeKgScKLyxejCwLLzVzfVzF5AF86rb9eTdWQIyOvHOf20RW0R45F+rY4sHvscvgUf+M29giwdy5ddcFhtn/tffJMBGzTztdHvGPBa67SK0flwflMBpOaDmzt3Zkqr5lQNHzafb5JOZfBBmJjCTF+CKMlMjsfAmNyMaHDr7DoI3tVE5AY/MEjkBZ2ZaN6WRrKFNl4XgkRmap3eTYjgzs7aFtmmSbdtIHraYgA0jGnBaHVrTAdoISK13+QDj945gV6t1OHZz13QbxFc2c2PEV3bDOO0dv6Tb47VD4sb2BebXP51HFllQ3ZPEWPiQXt+Nw0O0S55AZVdu0IKxXRHFsq8uhC+SEapzCIlv2cviblQMvckRdX5eBNLt7qmXp8inSsGAYtkzNfIpvEo0Fc9TiuOtmYxfx4KD0zqpvuiTi40xsCxsR1Da7NpFN3qDntPBArkRI9sXFKmy53ZPzF0GSX7WtbLwHoGQKtve5SDKeNtfKih7/aVZmJ3853E0ZSvEm9+urMZY1wDb4fRi1bTw+wLw27feQxYFcFqaH17+An7i/eDKbWRXAPWxstB7pnD3MOHKRkZFApUNt6c7T8m9G7Irol72u7P9vT1sDIRi2eFuyBEqZYcOMCJoXYsC9bKFN4QSYwxuPMqGm062Te9NgWV7QwhkoWN/0niUzY9mnrHD7HULTG/OgTP2hhwqZVMUB5J8CFr2pPP0glHxRwmgUnbzxqvJG2Ld4M9nkcO7bNBBQbr5XdTCKjkEnhkl8Cg7FgpbNr6XKAg4XRBwOgGs+3sGGNngqI3nHb+QiQfHzuw2/b7lw1yTI1rZO1wu+1c+cJcMn1M6e+2Uyg7MtvOr1u5vUXvLaU+D7OcrzQ4PGANHu+PIdbq+1Zmu7/5so/34iI55WOSukluVmaveHPRJUTQPiEITfZfGYt5q90gN2jru9C1L4+FT4sN7J8VrH3z5vd/9CxkjYfzWs4sNUs+RPUnZ77y9eP3chdHzX3SA7tq08/w5+fXOmL2CHWIhRtm8WsrHn2CfuIhRNojkNT/ZxA4xEots+1ExGQREuxJCs+xri1RwVIOPUaFN9ty8FeHoBj0jRJvs1dvYkiZi7NLSRFDZaBTRHzoEiIxC5D3DoSjba5QSDTQCbJjbzYw5DImMbER62ZatMh6pih7ZEDQ6uOoF78zgx+KXp1RnpyihLdoAOFvTbmZln53QGg7+PpUlCnTKZlGVlw1AEfwzIT1ok808QbykbL7yQ3avthAFEcl21EmV+jlS26SoHoVGUXZeKKpsPOxQBHC6COB0EcDpIoDTeeHsnf2WYY2HA9svusO9w62EaNiHZXHQBqPDMjituHL5s22P/iPWH6TjYUDkmvlnetM3iWWxRf6gSlm799+8aa7sDZ/mrd0d2vkTkTfNfK7qZ0P7Y86eUs0BqX/r+Cr74ebZ+8MH90C+4vywhzIKSV7znPOR/crGczCio5TV/LVjRkrnyKhstKbru9Wdl7w9ec1C+EMEpNvzvpXl6Ni1y/pXI5C3Poz2z+SC5NoF0L150zy2as14WKxh2fQfKD2jlzvNS48mWE/WP1nfIn1Eo83uSU6ID++dCJFrJlT30DcArQP7lnvolxzvvL2ILFEBnfZKY2/ylrOeOxKx8+P3qgnMQsHpuPj+tQ067eatX/wZ7dIOTsfC/NQlKjiBIANoTFA7f/krfV5vPbVPYl5GjJr/3eDVEuRWNYqcuDTf+woLBpBPXMQY57W6QzCcBeQQFzFq5gUnNGOQEodmMr2ISr268Opvn8JGshOOtGsmE8iYYGpMrlZT9GoeCk6oixaiUTO59qZPMKBL81BwJY5pUUro0fxkM7WCAT2aqeDkpnP7o609p1UwoLEPSy2lZnnkJ6mypQVGIu8ZjmCam+J5gF54TS9zI+8ZAhXNTXvWGwqIYAkD55xVNoWXMuN9vpo3hitNvP6mprmvSnGuiSejutfi8F+dwy3GfdbAolSVVNCgmc5u5i08XkFGZ2FS48RXPXGms1W9EAYQtRdw45ORokczQlIA+3Ko2KmZxa6kuTaUKqmZhVpnkAFtmqFVM+ehhuaIAIInKNcZZECbZjh0NmddIW411VWRAqBNM3Rj7Aokq9kU7N/tR4EmzTWrfsIuiLaMBqgXwy83+wL5f3QooqgZDkUI8uSvRsI/I6HLFVj4JIU5Ry1eRTPfLfGgOMv//IDKP8JZS2emFOecUGouBqXmYpCKeUMlcYDTJXkFp0vyCk6XZIfxW8+m67sXG52Vxh5s4MmtCJwuIm08rxphTrMGXKv+IXrKc69Vqe7RFzmOpHXQtd6awHAkCkoGIj3xsIeWBLXon3SOjMdHJ2ypSCcn1sqRAPuuApPuSK+2yTvhcFmnvW86E8hz6enKNy43wOhF8jqWHJDiSN89QosX23iV5aUlFevgJo5spGNnn76oScj2FvmjKeL8lvkKLxFlpAHZSJ/fcP6pF7N/3vG1ofn6WHxt5mgdHFVJ0d21UXdqZaSBtPbecn9rl6SMtAJxR7r+LXrzAKE/aOy0f+n903n81v8qzwx3Z1BGGkjvHZn9IknKyfp97ODHfUfnX0YaSG+kx5Z2+DV3escvF+H3EvYRsXporXJgkpIXrSROmiNNGL/n/K0FHfjmPl1aCnNzd26z13KMogysFT4cfgUl7ZGmTDw49lo1TUy/b62mRhlulSw9+u7if5AlhZy9s1990edXBhxiDLZfdOfuWK+McoDTxQOiO/3z5evnLvzo0t/RrlyB04Xhjd/84/JP3mfLirz2wZfIIW/gdK75zh8fnrvw0e8nf8UCDMxPXQI78swhaF5ZPnmy+eoPS9Y/mRF/+gg755RcR3qtblyew6HlWavjLPklb5Em60zYLx7zx2g+QnnzTR7btHDFK565efJ+RZQr7+S090YvUOQwlirYuRjkKtJkUS/Udc9ecSQ//RxlKQ45ibQgxlcXhgtRmk3c2HjA/AtI5iNNFnOzX4VKMRY+HMa4xCbDkXbHGJJpe+9teshkpEmTvbrAxxjus8oY+5OxSLtjDJfndL7OOW1kJ9JPNvGA18eflDGWJ1NtevU2izHeVTKKDN+RlShRRroolJEuCvFGenlKzzJbTbLGZsTriprfKVyPK5vEGOmmucKtrjVP9QRmxlzyFC2XBvVVoxBd6It0bcTKsEL82yWpK+rfyRi5GJ5gjV53BbJ1aVv6UBOaIy3fyKD1+Ie5NkvOb4BWq9CXQFxHXQLoBSiDvXp2Ih0Q1V4dDtv7MGinIr9QZppIU+8dJtK0xUfTo3oF21SkpTrGQRbbdFPQFUcZaQAOHnX4Zt+QwRsxRhYjTduW86RHHGmAP34a5qy2ZkoGe28aVLSuPTV6EfjKSn9lhfmG1JC5Nm02Lzj1yDn6Ng1wlTXL/TYla5HmRy1gmzW1aCNN77H542E/5TPbuDMVafBxn2jWwUYQafOY/Q7D7lGiKS5WMhJp0qTkWjwLA8Kr+2WNVS1sXMgz0rHri3RJuigjXRTKSBeFMtJFoYx0Meh2/w9GYL4FKFyxNgAAAABJRU5ErkJggg==

[sys-menu]:data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAR0AAACJCAIAAAHpj0tbAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACK0SURBVHhe7V1LUxtJuuWXdIR/wPyEu5uFF3c3y1kRd9V3MRHTgcPRHR0TfR3DuKM90+2JngfGYINtoGUwYIONAYF4GIEQ4ikhxEPIBhoj07bbC0eMOzp0T+aXlZWVVUISlEDCeeIYV2VlVSnr+07lo/JRU/PXOb/46s3PRDVE/mUU//lEz5vtluNmdCf1ZjJQ7MrQ0+BPe3vEw93d8pFuwW6GnVc7O9kXLw6eP3/pN3FNXBnXx11q6E7P19dzBfHpp4zHwu7WFu7Cbob7r8zNieBi8PJlrqFBbBeH9eVlJJHdbH97e2FmRgQ7ceHChVwuyzez9Rfq+YYTxaV1dX5+P5OpQep+TKdj4bAILg/ic3NIErvZXjo9V9LN6mrY35qaXFOGbWSachcvsl2g6SL7C/AjEjDTcW9GoKuzjbpczcXcRWvXC943++VX+t9neNzsp9Hrly5dosP1Ufo/l9sP1DI3ORE8bnYwfE3ejPshA/kidmXIMWDf7DS8MRZjNyOdLc7Otre03G5sbG5o8JctjY0dd+6sLiy8hM5wM2j7eSqFlELaSKK/xDWRrBfr63hD+pbFsHwrs+POzORfRvGfT3TcrPfHqdUdR6D478TEFT1T5gixt06BlIdSFlomyluInJqyad9zarompEy35JlnxvmKzofjZtMAbokbsTfI7uamCCsSpd91j4oFeIBQNAW1dweTr9kG3sIx5fVovSC9cPmy2DgSLzY2mKiRwMzamggrG5AecbPtUm9G2Sb+hupYlkz5tcxLvXCCm9nAbTJWgcDpZVR0sODLzYqFx82Qc8rMk5zCyq9jdsZ9LBS4GbnihasxbARqvUqMpcC+2Wl4I+Vn+Iec7UlPT2tT060bN7R89oTEBe80Nw8/ebKzucluRmWQ1NLSUiQy78pnT8j56eml2dn1lRWUPNgbRM8FKoCUCyJ3bIjuErUIjKEDiraZ2RfxnVlpRSfM+xdbdITff6FHc+ycJ8rSwTmjR8kKyqs6yh8P2gmjfRwutoRVqcCbVyaSlRixgyB6EYsovuD773NffcVKfB8+iJAyYyuRgG2QFpEwbO1nMijTIR8QUThYdn0QvHT5H2Kf59v1V5Fd2+VH5OH4W9uZpdp9UcWG1laWWquU6iOSi4soaSNtMBXLNA+4uTKpVGx6WkSxyiHAFfz7LkiB+N1ISW1tgHaRvkAt0sPSifTx5PLikWfr1tGYmBAbJwDq0Sh3IIMWpQEUdZAwFK2O05ZUJFB+lSSg8CoanjRhO3dDBYrYKlbm5lB6cyRsr9wJk210bmSaWE0BZfaLPA5LCSoOHDhLfRbAkW+3s0jYqaDYhF36cx/+/kQ71YCiEmY1N+7yvwJ4K7Aa9lW7rZFqNgTW8tmZxdtDjXCa8EhY2V8epwI9YfgPCUMQqjQiSnUiwZtNRcIog0amhsogMrhno6ODfX2Pe3r6Hjx41NX1sLOzkolfiN/5pLd36PHjyMTERjy+t7UFB4S1Kq7aMqXUwWjjuisOuKkcolO6nyoR7K3KoJoqqjv/3hUHpDhgQ3TP2n5rR7C3Ko/0cz1tRYdo+5O2Lb77Wh6tVg+8nn776iArdxHtv5Sj1ZoqMPFaxAQHJpKOo46dc0N9/3yQGgPOGfVUHZbzu1j5qKXivDVF2alSE4MC1EF5viyWg/Q78ZtBmTaWKpkkKhCK0mIVgpqfKG2OprXNeFxEOQlevmQNTCf4cns8bCeT+452tZ0dWPP5+nrMx4pWQ0MukWBpa28XIWXGSjS6K8vsZCjUTNLJZDgUElF8x/ffsxQeHordMgB1XxiG/NCuFG8mEhNB0SQI/OPypam3vBnUAurwACrzqNJTiGj3RChvCc3lsvJQXrx/z5JXf9Lvnm7MTk6iXm/XiJE+2G5jZWVsaEhEAV4n8SfYrfpPljd3sgSw9F24ENhnofhLLZ4XLtRSSLHo6WEp9KkaPjM+nl5dhXlgpBomKqRqc3N9eTn09CnFCH4HIzEcUKu1QBYpsVtdouJ5IyUsMFpfX2qqfEV4bGwrkaDqMPucjFShhp9aWhodGBBRqhB4KUBESBXefFaqNjaQqpEypYoaZcFME9vVGnfdDdX2O8v19qrJ2zA8hVTF45CSSBVe8+VNFYAkXWxiFNt1goCWKkq/BNJVx1PCngiPWuf9oj6LVAGsed2yVR1t5MlIKBkApZDsw9roQ+xbRGWlCqBUMfBfRlaiX6naR3VRLQlabyEFZ5eqcqLoVP36i9ioBhSZKvZtpO/PdtmiwlFUqigXBq6Pqp9+WIEIWS3yW54ds11s80MsnELOBMWmapf/vTaMAoZEFokJ7GfVbz9UemJfk1EsjNYXLgqWB6XZSqYKyZCgEACBlDyUcSlEPXqa0FN1PkpMLFWJhJUqXrplqVpeHrVKt9UIR+lW1ERQZl9ZCQ0OiihViOnx8a3VVTtV+A87G/H4ZDDY2dZ299atlps3fe8O6jtvNTTcbmxsbWq6d/t2byDAao3JpKhfybowKpLz4fDIkycDvb393d1V8K2xs7Ovq+txd/fAw4djg4Mr0ajdZ4a1xvAXBpwQaludn1+ORhdnZuanp9W+sJVJ/MjFSATpSS4spJPJvXQaCYGdzunXA18pPz4JZtjgneNyW71UYmVdHlLDX2UPZLiD+r6hi57WcoTk/3ioM/JKOzEf9ROJ+r6hi35ayzpxYEQPJ+7yo7upbS1cUN83dNFfa4HUEebV6ze/a7QDv1gUsuseXJKBOvV9w9Pibx5tbx7a9k5s7GkRPKjvG1Yy6QO4YVXQWKuamNdaqF0ani01i4AOa2mxUXmWzPIuDYblo/q0NUNIAwlrqcfoBLrEAe8StZ/J7G9vgz+C6bShz+TPFnypdECDPDTLCWvJfWYkbqeXmQyu8mJjQ7SWGpwudre2YDyynGoz0W9QmIqLCfF2Nze3Eol4SROInQJGRljPIWJ9fTlGiVYI1paWMqnUHm91lzqzrSVNBVXtbW1l1tYSCwszfgwmPQ309wsTXr7sVy+ws8XCzMzGygrebXhJwiJSYXbvVTIVXoA7ENbq6nI0Oglfrl7AbJ99JqxYbd/sos+epbi8tFeiw1o4AGG9WF/fiMcXI5Hx4WFxthP0jfzq4MFG159oWxxwgPUC4H0oGWrVYeL7AatnqESWuh3K4eYA/8QuwoHjDDR3I5EQMwuA7e2nNr9AqYhMTKwuLGwnkzuQF/+4RQZj3yLJWiQs5FjPU6n1lZX56Wnvz8i//hIZ7mnvaE8+Z71PDmJ9PcMRr4kPWcdQoJb+46AD2CBbKTajoby1gdpa2JJ39mA9R/23lidevhSdocES5+4sE6bHxxOxGN5wUA70I+XFrIVMTH0NItNKLS/HwmF3VwY2jNqJ4IEMvCYiKWDaitZTXyGyjbBZtD7L1QPDcMAqWepbdOFCvdVxxWEthzrPO8JjY3FYK5F47mEtZ6a1DWstLc3BWtXcnaaqMRUKrczNbcJaVtaFqpjDWqgCo8iIF6W0lt5Vsupgd5u1+sbW8bk2MiHR7xe4SB2AOTPYdU3GgVDqO6v3qLVi1lmnS1CHcUL+jrdHQFgrHj/X1pLdlekZua11sS7XxHumM8NY06WQHdi0i/JE6zryudOl3BcEyIqy/zcgzuJmFl6imboAPg5ryQkmPa3Fpu+RT81SDEC2oceqWYsA3eTrpA9oR0JNls74LehSxlqFoNjDhvUOBOmo9hxpT1grZNtbvNCsaUhV5DVExr64c57SgvgIrVXF8NlafV9f+vxvzc1/+/zS12zKJwN/4a+1Di5dE+Nbg9fYaElP0Nx3So2K/UeVKqpRyaO8aiwghzrw+hZDtrP2zAZ2nBF8sxbNNKbBOf5EgLc+iBYNQNZzAc1ahHrFVLA0gA3R3rEf0Jqqzjf8t9aNiUxm4gZte1qLtz4wazE78anhEEjmsawlG5/4LNy8gUNpjmKtG9TSyM61BjV/DChsLdGWUfBNeBAkC6kI5nsbGhwLRVuL2gmXllg7Yf5ShkFZEQ6F4rAWb3midkLFWjtsJl3ZBp9JpdaXl2PT03L6BYNTRt5WXfl9C9ZCKHQHe26srCzMzOT7vmVQbsyMj6/Oz6dXV9nn43QaRQrdWlTQwDHE2FxdxXtzemxsqL//UVfXg46O+21tgbt3O+7caW9tbW9paQNv375neFyyB9jSgoeJR/rD3buBe/e62tp6AoEnPT3jQ0Pz4TB1zRCZlvWxX1hLyAsG411oIEAaTwiFzU5OwmxTo6OTIyMTwSAENzY0xDg4GDI8LukZ4mFODA9PBoPPRkZQsoCk5qamlqNRlBvSa2soQ0A8MBUJi1nL7hFv6E170REiAq9nHCGv3rxynpKfT+1FV5xnqXd5o4Qr1PcNdXqY6tgcyHpf6vcrr9XwL5RTbOr7hjo9TPX7MbFqkcU8gxhdpEGPKluiu92ZN1rgQEg/kVHfN9Tp5wvQeVZeTkX0Exn1fcMieGxTJeQpr9/8b5tjlOr1tUN5wY5eO9ymvm+o009VfZF6y+MrM9GrHBFLvunhRH3fUKefpqr56yqd8vV9LZxx9IAd2k3nmX1D3zfU6a+p5j4ZFOX1qUWlMNKY2hQz8OcpqYP6vqFOn00F/nZCvOh0vlYWs3BT3zc8LbZsKHWpwzdfPFrRIujU9w0rlvq+YcVS3zesWNLwb8PKpzFV1dCYqmpY2FSH1iB+w7LT9fBVeptKv4ThqVOzCKibSjuBSB/1DctN7bGDqmkcptLiqVfJ0qw0hmWi8qhBzRBkHdtU6jF5jrzWgbWUHfGl4cmoPc8DaTNrMhJQtYhtKhkkLGQZCVfBdffNnFrlozWnFvX6A1WDSbuAzFRyR9iJR31ZzSs9VjXw5GX3P9VarCsgUdoJhmUdAre2xKkGpwvqWkvWklNp6aYSduKLIm4n2SqIlQI5xwuxDEtDVg7YkJD1dWktkpBtKmYny1R76XQmlVpbWhKnVg7k1FhgT48IPHeIz81tJRK7m5t4t1HW5TIVFSK4pBB1JaoMNKwcHB4yOwGdncJmX36ZW1zkx84JYuFwamlJCItKGVxYzm7rmQwKJHhX0pAQcWqFI53OffONMFtra+7nn0V41WJmYiKxsJBZW9vb2oJFpLCEqaSkcBj2XF9envNx/ehTg5zI8w9/yFXLtJUuhPkgxnQySe9AEpZuKir4IaOCAKPPnolTqxF4TzY3C7N9+21uZ0eEVwMmR0aWo9Gt1VVtMAgbwUimQhAzFZ/pLLm4ODs5KU7V8HaKjQe+/A9sXr/MNqfe0gEH2MB5Ap8YQU7+aGM/gINim88iyEZrW0O+AZwih3yfCMh0L18WZquGwshEMLg0O7uZSOgD4tS3Hw6wgdzJ5OrCQiTPCyTz6AqzD5+SkzauPPKoLDvms3BOcUDLt6tg8zwC+wF16grYTIQzxHyYJOHDh6oojIwPDy9GIhvxuNdsj/T2swYupldXV+fnZ8bHxakuBLvbk6/Zxi+HK+3d9jL7KlRT2dNqRtn6+hakGSxTKfbA6YF9GQ74YSoVFVwYGRsaolmK7QH3vIKlmMqa8RZvyUQsNp3HVD89T7Z3tLf3j/OpU3/ptOZT1YBnDdR3srecAJ+lAu80BNMGj8hABgzss8lkSHOxXKy8plKhFkYqYD7q0ODg/PT0OpnKyq48TIXiH5ujPRYLj42JU20c0BvPxnfB3PM+2tTmsoCpsp3MXNiGwdQ3G0AZmJSdNAlZkR89RVNJoDACtZ01Qk+fxmCq5WU2IliWLEozlcd0I9dkoNe8I8wS9KLj70M2kRLZhkxFhgRgEmZabEXrYRJesnCa6mOa0GcUpkItGKZyjggWpqIvHcxUqRTKHvG5OZTuxakGp4vRgQFqsDjKVMjEyFSogk0ZU50RYKo5birUmgqZKh6vQlMpU2wSL/L5S2usqWwdc2pmHFOqarOkahATn3pNpYnrM4TyT8YZ8poNtABGVFMpc+mfG1O5oM7hDLDU8ClPa6xpn+0Q4kU2yy1tiylSOfKZimLiIrShTr4q/UD7DcVBM9WeVQs+X6bCY6UHB9iPyRJcXROfcpibwZ44WhojJCYkRgTbUopY8TzUZ0LmlCZU1UOmkmIt0WAfh6no8dET91QV+5Nhczurj5Zekp6moodO4TQPuESRpsK2MZUHijGVgLJN7y6c6zYVXURckP2xIdVGVI8yUyE7JANbFykaxlS8KGGXMsgqgGUYJNdtKoYQi5xvOnY9D+OZH8Vlt+CXMqYqAPsBhew8322qujo2o75Ujy4RvC0tE9JrTYNnyVDiiBPz4+Mzla0bBWQJRn5U83dNVYhGEOG4Jk505lhHmIqtqWBBLR8WwsdnqqqFMVXVwH9TvX/3XmwZ+ApfTfVr5tKlS+0d7fib8Vjwz+BE8NNUwe8uWUWkDPtkZeArfDWVvUSIvW6IC1neOcL+IsX+44sWANTXhY7y78IWxCdHgH2vIiiBHwV8MxX/jqhDHHOhGFOxXblKiLWArVzWRcb5eHD6pmKf2PGgLVjfczk0U3HEFPXwxWCuxrKd4qyPasVTv031F7aoVd9fxB4dckKYClt46DBVdt/u+kKmIktQFwwVLIK1AfvRWaKf2kcA31X1p3fv3olFuj1NxXtDcFUxe+B//PU0FVDvtAoB52Z57wwKVJblOec47RcgPWIHXM+aTEXvPRwn+8Gg9dEsixqtF0rivQeNqko2FXV+duDydXHMwA9opjLdYCoXRXWDMZ3LKgEFOpdhS5jqqN61BqeBAl02jakqB8V2hC44vMCg3ChieEHRg3YMyorx4eECg3awD1Ph5UhD4WYnJ4efPOkNBDru3Ll3+/ad5ubWpqaWxsbbjY23bty41dDQbHgCsmd44wYeZsvNm3iwd2/dam9p6Wxre9LTMxkMLs7Oeg+FI2vBVAiFGWnSivlweHxoCGf2BAJdbW2Be/d+sJbxoyXo1EXpDEtiG1/GD7ahZfwCd+/eb2t70NHxqKtrqL9/emwMlaXNAisuWiULmHQlGo1MTIwNDg49fjzw8OGT3t7H3d19Dx70dXXhio86Ox8anoDsGXZ14Xn2d3c/7ukZ6O0d7OsbefLk2egoRJJcXNQqVbqp5DswzVcKXo5G56amkGmhOvxsZATCnBgelsstypUDDUslBGAvtxgMTo6MTI2OQkzIdJBLoaCAqi0EgzIFy6i4nWAjfYoRJiwULtbX08kkCiHJhQUU3KGwpdnZxUgEF0LhBETB3/AkhHTwGPE8F2dmliIRqAIvPRgJCmF2Uovp0lRiunVDw+NzZ0oubuLJjFjmybXsjcZX1x2X9YHWgmFuHrZ06JEZO/ZiekzB3VSxyzQy6vuGhiWzWF2dNnt/tNdM9OCb7hHH+ka/Gdnf1OOofO29tKIn9X1Dw5JZqflV5JXrFiei9+qyntT3DQ1L5voXjmWtXRxbp5inravQgXvlbMnd/cOBld3rY5u/602B/zO207Kaje3nKzeCb70X2Pakvm9oWDaeev1qeyDrvMX+wf95Lffr5ic9L2gNYJvZgy9c0fJS3zc0LJmV225R81StMr3pHnQsS380Pxl0nvtUj3AU9X1Dw5JZwboC7+9MHSp3Och+3VNAXXpmdfjqenG5nE1939CwZFa2rjh/G3ml17Vev93ceYUqlqgErhxM7bzZfe2M8+btVCSpXaoo6vuGhiWzCnQl2JJuybxx3deDm5m9P7a4Ti+e+r6h4UfDT9rWfteb+uPUbsNUGhv/3VZC7asA9X1DQ8OTU983NDQ8OfV9Q0PDk5PW4TY0NPSRRleGhv6zLLo6BK3V2A0Nq4MuNz4Jj6kr/TcZGp53ahI4msXqSrtHMXxlDW41NKxouly3GGoC0XiUrrQLuan/vjzMSr54YWh49rQcUnPUfNTc3k1NOKC3rrTTVGq3JOq/W+EB8flzQ8PKIvdMzV1Vak5O1OSgUlWQristKlG7tJbzuGXzkk9AUyT3DQ3LRs3ZjqLThxkVJ2d0qgDUZEIkHdm60g4T1avIG+CW8tewX7+9TfwRTKcl98CtLUPDSqfitIyWPzNK1VlzLRFVXWiSIQpdaaGgPE3mTjIXwo3xa8T8kQYGHwHg8HB7oTEpsPzqYrrSgmRUkM6nDArahZp3Nzefr69n1tbEDQ0kUikP7uyIowbVDDg8zecICVAmJrMvVS9SRGyqR5UyhlAUFxUV9nb5VODba2ub8fja0pK4oYGGRCL31Ve5Tz/1YE+PiGNQbYDDw+3h/JAATesNUUAasg4mhUM6cuhKHhOi4rU3llPR/PobG9t8XtXV+fnFSETc0CAf3r/PdXbm/vAHISq5IXcbGnITE7nDQxHfoIIBh4fbw/khAQgBcoAoKNcC3dKydSVD3aJC3rezsZFJpbYSieTCwuLs7OzkpLihQTFAgXBxUWwTIKfp6Vxzc+6zzxx6+/bb3OCgKT1WGuDwcHs4PyQAIdBaZEdIS+hK7rtFRc16rATIM6tELDYfDk+b1XvKAWRx0WiutTX35ZcOsdXXszIkxGlwRoDDw+3h/CLL4iuHsBUZ80jLQ1dUp2KiskqArK0ilUqvrqaWl5fn5uampp6NjoobGpwCUGdDkVKrtkF77e0sG/zwQUQzKBvg8HB7OD8kACHQWgdUGpTNGFTXsnWliorpCqJSSoA4nxUC19aQA64tLi5Fo7PPnk0G8y16nwfvdiP97e3d4xvvRADDu43x7vb2/siuGmhQJNJplol9841DbJcvs+wOJcyffxbRDPwAHB5uD+eHBFhRkC9LK5oHqf3dmWXZuqLvVHZmxUUFReJ8KgRuxuOschWJRCYnJ4aHxQ2LQObRFbH6MMfVwQMEbnTJdb4ZrjzKUORCyAZqaSloucFWBa+tDWRpfXZlkWl9/WkJHtkGX16aozawL8JYoHUpdln1FByydnGL2s6sc134+rNcUvzly9zISO777x1iM20kJwYcHm4P54cEWMMgLwpCGhCIo6LFdQUpKbryyqxIV8/5Cksb8fjqwsJCJDIzMTE+NCRuWAwOgvYK35evB5ms8gQWBpOTRH3UsWtBkQckxwMcQqJAIRvPK3iBLsLOpevjROVGArH6s9WVJyAniMq0kZwAcHi4PZwfEoAQIAeIQtOVmmXVyNEctq5IVLzFgr5ZUeWKNVrMz8/PzEyPj4/BHmcDmU3JDQ7m7kc7NDzeJTAHNJ0oCnHkh/Ust6ouXXlCtpGg6KiKzbSReAEOD7eH80MCEAJVsSANCIR1g+KdnijLsnSlVK7chUCUIHEya2GHrpaXWWPg9PT02Fjo6VNxwyPw67uN4eYrn4s8yYHLV24Mb7z7FZHez7daBcLPrzSLwCOQR1e8LGfvcjiLZx6g+Epx0aETGe68LJRzLnTliQ8f9DYSCM+AL6LOmgSnp1mT4PIy5ABRMF3x1gt3UdBaW5h0xTMyTVfUawl1tdTycjwWi01Ph8fGRgvq6iB4TcjlCFxjxT89Jg/MA+nrtZ0xW1dWhYdqOzxIgmVT7mhqNcyCohOu0gu1tVaRT625nWtdGeQBHB5uD+eHBCAEarqgnk26rniWZa/Z7amrHd7Cjktskq7m5mLhcDgUKqyrd8mnHe3tBfg0+c4dkwcWBs+vrjLVOP2YhUMDTDxWqU9Ro6o6S3JU3WKHvUqJpDH7Lp66YpcS8FCsQdWD6SoUgvNDAhAC5MB0lUpBIEXpSm+0UHW1tISLzoXDU9DVwIC4oYHBRwA4PNwezs90xZfr9tSVbLo4Sleok7HGwFSK9bXlulqxdDVidFWZaGoSG4RQXS4kNhm0XRuZ3MWaXJ33sULg5zZZn0nqirtOXZ3YkGi6mLvo/PHeCOVqaiziIvzuMuSYSSgMODzpChIgXUEUTFcbG5BJCbqixkBbV/G40VWlINOU1wXhnZprQUvkbdiQ3q8D3nkRf4qD6tnF0CUhAn6qlIH7ZwtYskF6kWq6oJ2KUHFS9AG6rnjfdqkr2aHpKF2J7ktGVxWLonQFj5QOnW9bQtEVLk7ujkvZHqxE0OG8YIZHQq4FAXhKxXFZHlONVpfnLo4k8x+jZlOCxb8aSkYxumIdmoyuKh2a/6m7JegKf+G4clv+1YBAyyll/na0rhCNubJ1Kfwk9dey+GrGogCXdYhBY9G6omiy3CtfB+WB0dV5gQ+60lxW0q0rpUAli4tH64qAOLY3Z3J1dBFEdt/CgpauY+dXFE1ezejKoCjAYzQ9lKYrAGrxyhxUtyaovi631UDVlXF37YIkVFb2wymUj6l0asxxWbeu8gjSvil+hvJj5OlGVwZFAR7jFgAhn65E2Uy+8j0bGORRC5pHyhwjn6504BD/qRQ/b+vIcVs7NOEx4F4UhGvidvxVQvW6ssHo6hyDezC5Xb78ygHudg645AEZSK8lWUpVFNQVy0OUQDU+XaqYDMRDNsUBt1AfAu7ufmX4B6MrAwlPXeUpaBUPJievizh0WCT4m6IEXVGml08/oWNKtAgYXRkY+A+jKwMD/1HZuvpld9weOPL5leZg5r04YmBQyahcXe32X4WYrg/bg0AOhq8j5Gr/rtg3MKhUVKyu+CgrfWiVZ+DRYMNArOEefEiIDveYKAGv0VmFIIeQKKM/XMO35MgRg3OLytPV+2TPNc8xww58fq0nWXKZsJCurIGMBKeu2LnOgcAcJKT8Y6jkAMcjBiOXrF6DikfF6epguIhxwxzXlCJiPlgjFGmUoVsbCHHq6kjY5+aN6ciIpDLZz9BHKDtvbXC+UAW6+lNDX2Qh0tfgmOcMKEZXHHKsu9AVsg4li7BLZXB6VXWKBhiUofUCTC0M9gBkFqLlXfuBAF0znxQ9Bx0bVDkqXld/H7dG2b8b/7sIIxxbVyKEObqevZSkKxvOAqQqYFV1DIjJL6Jd3OCcoQryq3woSlcyl2B+L3Wlwi6PWflPfli6osqSfSlFV3QRcUg0Y9D12d3lFaSujpKrQdXCB135O17YZ10ZGJwFitFVUePw/Zzf4j/v3xXC+/+IuAYGFQhdV8ee3wJRzXxMBgaEk87HxKSVT1clzR9oYHCOcNz5A7m03Lo6/ny3BgbnCExXx5jvlrIsn+dnNzA4Lyh9fvYqW0/EwOAMUPJ6IqWuf8XWlZuYGB8eHu7v7+vufvDDD/fv3m1vbb1369adpqbWmzdbGhtvNzbeunHjVkNDM/jvfzcR//Wvmyr/+c9GQ8NTIZxN9T24IvkknBMuCkeFu8Jp4bpwYLgxnBkuDceGe8PJ4epweLg9WxW/yPWvCq7XSEVBWq9xbXFxeXY2ytcXHh0YGHj06FFXV/cPP3S2tQXu3u1obW1vaWm7ffve7dt3b90C7zQ3g63QG2cLVKeRJ8bQsIzUXO7mTemQ5J/kq3BauC4cGG4MZ4ZLw7Hh3nByuDocHm4P54cE2Mcrvl5jvkKgY73GAlkWFQVRxZqfh2pnJyenRkdR6Bzq73/y8OHj7m78goednb337/cEAiB+U3dHxwOwvb2L2NaG3+rgvXv3DQ3LTLiZ5nhwRfJJOCdcFI4KdyW/hQPDjeHMcGk4NtwbTg5Xh8PD7Vkh0Fq3+4jMClJiutKkZWdZlrSgS1yFWgVxXWSFS9HofDg8OzERDoUmR0aQS6IAil8wMjAQfPIk+PjxMNjfj5811Nc3SHz06KnGhw/BAUPDspF8THM8uCL5JJwTLgpHhbvCaeG6cGC4MZwZLg3HhnvDyeHqcHi4PWux4C2BkANEQaJi3ZeUzIp05KErJi0uPpFlKdJiuRYqWrzNPbmwEI/FlqNR6Bj1Odx7LhxGXjn77BkYmZxEeXSGOD6OOh/j2BgYNjQ8I5IHkjfCLck/4ahwV/JbODDcGM4Ml4Zjw73h5HB1ODzcnlWrqI8FF5XaXAGSdpiOdnb+H2lcBrY4xOj9AAAAAElFTkSuQmCC