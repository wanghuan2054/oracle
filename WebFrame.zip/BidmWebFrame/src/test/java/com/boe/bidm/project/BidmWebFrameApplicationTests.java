package com.boe.bidm.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BidmWebFrameApplicationTests {

    @Test
    void contextLoads() {
    }

}
