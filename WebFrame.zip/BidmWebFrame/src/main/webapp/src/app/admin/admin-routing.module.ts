import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BidmMenuComponent, BidmRoleComponent, BidmUserComponent } from 'bidm-web';

const routes: Routes = [
  {
    path: 'user',
    component: BidmUserComponent,
    data: {
      tabLabel: 'user',
      destroy: true
    }
  },
  {
    path: 'role',
    component: BidmRoleComponent,
    data: {
      tabLabel: 'role',
      destroy: true
    }
  },
  {
    path: 'menu',
    component: BidmMenuComponent,
    data: {
      tabLabel: 'menu',
      destroy: true
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
