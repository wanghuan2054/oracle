import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { LoginComponent, AuthGuard, SuperKeyComponent, PwdResetComponent } from 'bidm-web';

const routes: Routes = [
  { path: '', redirectTo: 'bidm', pathMatch: 'full' },
  { 
    path: 'bidm',
    component: AppComponent,
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
    children: [
      {
        path: 'admin',
        loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
        data: {
          config: {
            rowsPerPage: 10
          }
        }
      }
    ],
    data: {
      env: environment
    }
  },
  {
    path: 'login',
    component: LoginComponent,
    data: {
      env: environment
    }
  },
  {
    path: 'super-key',
    component: SuperKeyComponent
  },
  {
    path: 'pwdreset/:account/:key',
    component: PwdResetComponent
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
