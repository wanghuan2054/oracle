import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng';
import { BidmConstants, BidmResult, BidmService, DomService } from 'bidm-web';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { registerLocaleData } from '@angular/common';
import zh from '@angular/common/locales/zh';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  env: any = environment;
  public menuList: MenuItem[];

  constructor(
    private bidm: BidmService,
    private http: HttpClient,
    private dom: DomService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    if (this.bidm.isNotEmpty(this.env.theme)) {
      this.dom.setTheme(this.env.theme);
    }

    if (this.bidm.isNotEmpty(localStorage.getItem(BidmConstants.get('language')))) {
      this.translate.use(localStorage.getItem(BidmConstants.get('language')));
    }

    registerLocaleData(zh);

    if (this.bidm.isEmpty(this.env.offline) || !this.env.offline) {
      this.bidm.request('get-menu-by-user').then(
        (res) => {
          // console.log(res);
          const result: BidmResult = this.bidm.check(res, 'get-menu-by-user');
          if (result.isSuccess) {
            if (res.params.admin) {
              this.http.get('assets/boe/admin-menu.json').subscribe(
                (data) => {
                  this.menuList = data['items'];
                }
              );
            } else {
              this.menuList = <any[]> res.params.result;
            }
          }          
        }
      );
    } else {
      this.http.get('assets/boe/menu.json').subscribe(
        (data) => {
          this.menuList = data['items'];
          // console.log(this.menuList);
        }
      );
    }
  }
}
