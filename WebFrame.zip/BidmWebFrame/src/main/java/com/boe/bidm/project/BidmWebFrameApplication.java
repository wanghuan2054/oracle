package com.boe.bidm.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = { "com.boe.bidm" })
@EnableScheduling
public class BidmWebFrameApplication {

    public static void main(String[] args) {
        SpringApplication.run(BidmWebFrameApplication.class, args);
    }

}
